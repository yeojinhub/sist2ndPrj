package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.DBConnection;
import DTO.AccountDTO;
import DTO.PaginationDTO;

public class AdminAccountDAO {
	
	private static AdminAccountDAO accountDAO;
	
	private AdminAccountDAO () {
		
	} //AdminAccountDAO
	
	public static AdminAccountDAO getInstance() {
		if( accountDAO == null ) {
			accountDAO = new AdminAccountDAO();
		} //end if
		
		return accountDAO;
	} //getInstance
	
	/**
	 * 전체 유저 수를 조회합니다.
	 * @return 전체 유저 수
	 * @throws SQLException 예외처리
	 */
	public int getTotalUserCount() throws SQLException {
		int totalCount = 0;
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder countQuery = new StringBuilder();
			countQuery
			.append("	SELECT COUNT(*) as total_count	")
			.append("	FROM account	")
			.append("	WHERE ROLLTYPE = 1	")
			.append("	  AND withdraw = 'N'	")
			;
			
			pstmt = con.prepareStatement(countQuery.toString());
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				totalCount = rs.getInt("total_count");
			}
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		}
		
		return totalCount;
	} //getTotalUserCount
	
	/**
	 * 전체 유저
	 * @return userList
	 * @throws SQLException 예외처리
	 */
	public List<AccountDTO> selectAllUser() throws SQLException {
		List<AccountDTO> userList = new ArrayList<AccountDTO>();
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder selectAllQuery = new StringBuilder();
			selectAllQuery
			.append("	SELECT acc_num, name, user_email, tel, input_date	")
			.append("	FROM account	")
			.append("	WHERE ROLLTYPE = 1	")
			.append("	  AND withdraw = 'N'	")
			.append("	ORDER BY input_date DESC	")
			;
			
			pstmt = con.prepareStatement(selectAllQuery.toString());
			rs = pstmt.executeQuery();
			
			AccountDTO accountDTO = null;
			
			while( rs.next() ) {
				accountDTO = new AccountDTO();
				accountDTO.setAcc_num(rs.getInt("acc_num"));
				accountDTO.setName(rs.getString("name"));
				accountDTO.setUser_email(rs.getString("user_email"));
				accountDTO.setTel(rs.getString("tel"));
				accountDTO.setInput_date(rs.getDate("input_date"));
				
				userList.add(accountDTO);
			} //end while
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		} //end try finally
		
		return userList;
	} //selectAllUser
	
	/**
	 * 페이지네이션을 적용하여 사용자 목록을 조회합니다. (Oracle 12c 이상)
	 * @param pagination 페이지네이션 정보
	 * @return 페이지에 해당하는 사용자 목록
	 * @throws SQLException 예외처리
	 */
	public List<AccountDTO> selectUsersByPageOracle12c(PaginationDTO pagination) throws SQLException {
		List<AccountDTO> userList = new ArrayList<AccountDTO>();
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder selectPageQuery = new StringBuilder();
			selectPageQuery
			.append("	SELECT acc_num, name, user_email, tel, input_date	")
			.append("	FROM account	")
			.append("	WHERE ROLLTYPE = 1	")
			.append("	  AND withdraw = 'N'	")
			.append("	ORDER BY input_date DESC	")
			.append("	OFFSET ? ROWS FETCH NEXT ? ROWS ONLY	")
			;
			
			pstmt = con.prepareStatement(selectPageQuery.toString());
			pstmt.setInt(1, pagination.getOffset());
			pstmt.setInt(2, pagination.getPageSize());
			
			rs = pstmt.executeQuery();
			
			AccountDTO accountDTO = null;
			
			while( rs.next() ) {
				accountDTO = new AccountDTO();
				accountDTO.setAcc_num(rs.getInt("acc_num"));
				accountDTO.setName(rs.getString("name"));
				accountDTO.setUser_email(rs.getString("user_email"));
				accountDTO.setTel(rs.getString("tel"));
				accountDTO.setInput_date(rs.getDate("input_date"));
				
				userList.add(accountDTO);
			} //end while
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		} //end try finally
		
		return userList;
	} //selectUsersByPageOracle12c
	
	/**
	 * 페이지네이션을 적용하여 사용자 목록을 조회합니다. (Oracle 11g 이하 - ROWNUM 사용)
	 * @param pagination 페이지네이션 정보
	 * @return 페이지에 해당하는 사용자 목록
	 * @throws SQLException 예외처리
	 */
	public List<AccountDTO> selectUsersByPage(PaginationDTO pagination) throws SQLException {
		List<AccountDTO> userList = new ArrayList<AccountDTO>();
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder selectPageQuery = new StringBuilder();
			selectPageQuery
			.append("	SELECT * FROM (	")
			.append("		SELECT ROWNUM as rnum, acc_num, name, user_email, tel, input_date	")
			.append("		FROM (	")
			.append("			SELECT acc_num, name, user_email, tel, input_date	")
			.append("			FROM account	")
			.append("			WHERE ROLLTYPE = 1	")
			.append("			  AND withdraw = 'N'	")
			.append("			ORDER BY input_date DESC	")
			.append("		) WHERE ROWNUM <= ?	")
			.append("	) WHERE rnum >= ?	")
			;
			
			pstmt = con.prepareStatement(selectPageQuery.toString());
			pstmt.setInt(1, pagination.getEndRowNum());
			pstmt.setInt(2, pagination.getStartRowNum());
			
			rs = pstmt.executeQuery();
			
			AccountDTO accountDTO = null;
			
			while( rs.next() ) {
				accountDTO = new AccountDTO();
				accountDTO.setAcc_num(rs.getInt("acc_num"));
				accountDTO.setName(rs.getString("name"));
				accountDTO.setUser_email(rs.getString("user_email"));
				accountDTO.setTel(rs.getString("tel"));
				accountDTO.setInput_date(rs.getDate("input_date"));
				
				userList.add(accountDTO);
			} //end while
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		} //end try finally
		
		return userList;
	} //selectUsersByPage
	
	/**
	 * 검색 조건에 따른 사용자 수를 조회합니다.
	 * @param searchType 검색 유형 (name, email, tel)
	 * @param searchKeyword 검색어
	 * @return 검색 조건에 맞는 사용자 수
	 * @throws SQLException 예외처리
	 */
	public int getSearchUserCount(String searchType, String searchKeyword) throws SQLException {
		int totalCount = 0;
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder countQuery = new StringBuilder();
			countQuery
			.append("	SELECT COUNT(*) as total_count	")
			.append("	FROM account	")
			.append("	WHERE ROLLTYPE = 1	")
			.append("	  AND withdraw = 'N'	")
			;
			
			// 검색어가 null이 아닌 경우에만 조건 추가 (PaginationUtil에서 이미 처리됨)
			if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
				switch (searchType) {
					case "name":
						countQuery.append("	AND name LIKE ?	");
						break;
					case "email":
						countQuery.append("	AND user_email LIKE ?	");
						break;
					case "tel":
						countQuery.append("	AND tel LIKE ?	");
						break;
				}
			}
			
			pstmt = con.prepareStatement(countQuery.toString());
			
			if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
				pstmt.setString(1, "%" + searchKeyword + "%");
			}
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				totalCount = rs.getInt("total_count");
			}
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		}
		
		return totalCount;
	} //getSearchUserCount
	
	/**
	 * 검색 조건에 따른 사용자 목록을 페이지네이션으로 조회합니다. (Oracle 12c 이상)
	 * @param searchType 검색 유형 (name, email, tel)
	 * @param searchKeyword 검색어
	 * @param pagination 페이지네이션 정보
	 * @return 검색 조건과 페이지에 해당하는 사용자 목록
	 * @throws SQLException 예외처리
	 */
	public List<AccountDTO> searchUsersByPageOracle12c(String searchType, String searchKeyword, PaginationDTO pagination) throws SQLException {
		List<AccountDTO> userList = new ArrayList<AccountDTO>();
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder searchQuery = new StringBuilder();
			searchQuery
			.append("	SELECT acc_num, name, user_email, tel, input_date	")
			.append("	FROM account	")
			.append("	WHERE ROLLTYPE = 1	")
			.append("	  AND withdraw = 'N'	")
			;
			
			// 검색어가 null이 아닌 경우에만 조건 추가 (PaginationUtil에서 이미 처리됨)
			if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
				switch (searchType) {
					case "name":
						searchQuery.append("	AND name LIKE ?	");
						break;
					case "email":
						searchQuery.append("	AND user_email LIKE ?	");
						break;
					case "tel":
						searchQuery.append("	AND tel LIKE ?	");
						break;
				}
			}
			
			searchQuery.append("	ORDER BY input_date DESC	");
			searchQuery.append("	OFFSET ? ROWS FETCH NEXT ? ROWS ONLY	");
			
			pstmt = con.prepareStatement(searchQuery.toString());
			
			int paramIndex = 1;
			if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
				pstmt.setString(paramIndex++, "%" + searchKeyword + "%");
			}
			pstmt.setInt(paramIndex++, pagination.getOffset());
			pstmt.setInt(paramIndex, pagination.getPageSize());
			
			rs = pstmt.executeQuery();
			
			AccountDTO accountDTO = null;
			
			while( rs.next() ) {
				accountDTO = new AccountDTO();
				accountDTO.setAcc_num(rs.getInt("acc_num"));
				accountDTO.setName(rs.getString("name"));
				accountDTO.setUser_email(rs.getString("user_email"));
				accountDTO.setTel(rs.getString("tel"));
				accountDTO.setInput_date(rs.getDate("input_date"));
				
				userList.add(accountDTO);
			} //end while
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		} //end try finally
		
		return userList;
	} //searchUsersByPageOracle12c
	
	/**
	 * 검색 조건에 따른 사용자 목록을 페이지네이션으로 조회합니다. (Oracle 11g 이하 - ROWNUM 사용)
	 * @param searchType 검색 유형 (name, email, tel)
	 * @param searchKeyword 검색어
	 * @param pagination 페이지네이션 정보
	 * @return 검색 조건과 페이지에 해당하는 사용자 목록
	 * @throws SQLException 예외처리
	 */
	public List<AccountDTO> searchUsersByPage(String searchType, String searchKeyword, PaginationDTO pagination) throws SQLException {
		List<AccountDTO> userList = new ArrayList<AccountDTO>();
		
		DBConnection dbCon = DBConnection.getInstance();
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection con = null;
		
		try {
			con = dbCon.getDbCon();
			
			StringBuilder searchQuery = new StringBuilder();
			searchQuery
			.append("	SELECT * FROM (	")
			.append("		SELECT ROWNUM as rnum, acc_num, name, user_email, tel, input_date	")
			.append("		FROM (	")
			.append("			SELECT acc_num, name, user_email, tel, input_date	")
			.append("			FROM account	")
			.append("			WHERE ROLLTYPE = 1	")
			.append("			  AND withdraw = 'N'	")
			;
			
			// 검색어가 null이 아닌 경우에만 조건 추가 (PaginationUtil에서 이미 처리됨)
			if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
				switch (searchType) {
					case "name":
						searchQuery.append("	AND name LIKE ?	");
						break;
					case "email":
						searchQuery.append("	AND user_email LIKE ?	");
						break;
					case "tel":
						searchQuery.append("	AND tel LIKE ?	");
						break;
				}
			}
			
			searchQuery.append("			ORDER BY input_date DESC	");
			searchQuery.append("		) WHERE ROWNUM <= ?	");
			searchQuery.append("	) WHERE rnum >= ?	");
			
			pstmt = con.prepareStatement(searchQuery.toString());
			
			int paramIndex = 1;
			if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
				pstmt.setString(paramIndex++, "%" + searchKeyword + "%");
			}
			pstmt.setInt(paramIndex++, pagination.getEndRowNum());
			pstmt.setInt(paramIndex, pagination.getStartRowNum());
			
			rs = pstmt.executeQuery();
			
			AccountDTO accountDTO = null;
			
			while( rs.next() ) {
				accountDTO = new AccountDTO();
				accountDTO.setAcc_num(rs.getInt("acc_num"));
				accountDTO.setName(rs.getString("name"));
				accountDTO.setUser_email(rs.getString("user_email"));
				accountDTO.setTel(rs.getString("tel"));
				accountDTO.setInput_date(rs.getDate("input_date"));
				
				userList.add(accountDTO);
			} //end while
			
		} finally {
			dbCon.dbClose(con, pstmt, rs);
		} //end try finally
		
		return userList;
	} //searchUsersByPage

} //class